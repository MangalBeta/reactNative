import React, { Component } from 'react'
import {View, AsyncStorage, Text, Platform } from 'react-native'
import { Provider } from 'react-redux'
import { createRootNavigator } from './src/Routes'
import getStore from './src/Store';
let store = getStore()
export default class App extends Component {
  render() {
    const Layout = createRootNavigator();
    return (
      <Provider store={store}>
        <View style={{ flex: 1 }}>
          <Layout />
        </View>
      </Provider>
    );
  }
}
