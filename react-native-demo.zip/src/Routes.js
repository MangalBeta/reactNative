import React from 'react'
import {
  DrawerNavigator,
  StackNavigator,
  TabNavigator,
  addNavigationHelpers
} from 'react-navigation';

import Auth from './Components/Auth/AuthNavigationConfiguration'
import Dashboard from './Components/Dashboard/DashboardNavigationConfiguration'
import SideBar from './Components/Sidebar'
import Splash from './Components/Splash'
//Drawer
const Drawer = DrawerNavigator(
  {
    Dashboard: {
      screen: Dashboard,
      navigationOptions: {
        header: null
      }
    },
  },
  {
    initialRouteName: "Dashboard",
    contentOptions: {
      activeTintColor: "#fff"
    },
    contentComponent: props => <SideBar {...props} />
  }
);

//Root navigator
export const createRootNavigator = () => {
  return StackNavigator({
    Splash: {
      screen: Splash,
      navigationOptions: {
        header: null
      },
    },
    Auth: {
      screen: Auth,
      navigationOptions: {
        header: null
      },
    },
    Drawer: {
      screen: Drawer,
      navigationOptions: {
        header: null
      },
    },
    }, {
      initialRouteName: "Drawer",
    })
}
