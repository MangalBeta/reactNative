import React, { Component } from 'react'

import {
    View,
    ImageBackground,
    Image,
    TouchableOpacity,
    Text,
    ActivityIndicator,
} from 'react-native'
import { Header } from 'react-native-elements'
import Icon from 'react-native-vector-icons/FontAwesome';

class HeaderComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
        }
    }
    leftComponent() {
        return (
          <Text> Left</Text>
        )
    }

    render() {
        return (
            <Header
                placement="left"
                leftComponent={this.leftComponent()}
                centerComponent={{ text: this.props.title, style: { color: '#fff',fontSize:18} }}
                rightComponent={{}}
            />

        );
    }
}

export default HeaderComponent
