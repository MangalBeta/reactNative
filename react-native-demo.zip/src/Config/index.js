export const APIBaseUrl = 'https://prodmycryptoswebapi.azurewebsites.net'
export const LoginApiUrl = APIBaseUrl + '/token'
export const SignupApiUrl = APIBaseUrl + '/api/Register/CreateAccount'

export const APIConstants = {
    ClientId: 'MyCryptosApp',
    ClientSecret: 'Abc@1235!',
    LoginGrantType: 'password',
    RefreshTokenGrantType: 'refresh_token'
}
