import { SIGNUP_ACTION_TYPES ,LOGIN_ACTION_TYPES} from './ActionTypes'
import { SignupApiUrl } from '../Config'
import { LoginApiUrl, APIConstants } from '../Config'
import axios from 'axios'

//create account signup function
export function createAccount(dataToPost) {
    
    return (dispatch) => {
        dispatch({ type: SIGNUP_ACTION_TYPES.SIGNUP_REQUEST })
        axios.post(SignupApiUrl, dataToPost, 
        { headers: { 'Content-Type': 'application/json' } }
        ).then((response) => {
            if (response && response.data.Success) {
                dispatch({ type: SIGNUP_ACTION_TYPES.SIGNUP_REQUEST_SUCCESS,
                payload: { formError: null, successMessage: response.data.Message } })
            }
            else {
                dispatch({ type: SIGNUP_ACTION_TYPES.SIGNUP_REQUEST_FAIL, 
                payload: { formError: response.data.Message, successMessage: null } })
            }
        }).catch((err) => {
            dispatch({ type: SIGNUP_ACTION_TYPES.SIGNUP_REQUEST_FAIL, 
            payload: { formError: 'Something went wrong. Please try again later', 
            user: null } })
        })
    }
};

//login user function 
export function loginUser(username, password) {
    return (dispatch) => {
        dispatch({ type: LOGIN_ACTION_TYPES.LOGIN_REQUEST })
        const dataToPost =
         "username=" + username + "&password=" + password + "&grant_type=password&client_id=" + APIConstants.ClientId + "&client_secret=" + APIConstants.ClientSecret;
        axios.post(LoginApiUrl, dataToPost, { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
        .then((response) => {
            if (response && response.data.userName) {
                 dispatch({ type: LOGIN_ACTION_TYPES.LOGIN_REQUEST_SUCCESS,
                  payload: { formError: null, user:response.data} })
            }
            else {
                dispatch({ type: LOGIN_ACTION_TYPES.LOGIN_REQUEST_FAIL,
                  payload: { formError: 'Something went wrong. Please try again later', user: null } })
            }
        }).catch((err) => {
            if (err.response.data.error_description) {
                dispatch({ type: LOGIN_ACTION_TYPES.LOGIN_REQUEST_FAIL,
                  payload: { formError: err.response.data.error_description, user: null } })
            }
            else {
                dispatch({ type: LOGIN_ACTION_TYPES.LOGIN_REQUEST_FAIL,
                  payload: { formError: 'Something went wrong. Please try again later', user: null } })
            }

        })
    }
};
 //Logout User
export function logOutUser() {
    return (dispatch) => {
        dispatch({ type: LOGIN_ACTION_TYPES.LOGOUT_REQUEST_SUCCESS})
    }
};

//Clear Message 

export const clearErrorMessge = () => {
    return (dispatch) => {
        dispatch({ type: LOGIN_ACTION_TYPES.CLEAR_MESSAGE})
    }
}
