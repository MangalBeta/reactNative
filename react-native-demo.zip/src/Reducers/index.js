import { combineReducers } from 'redux'
import AuthReducer from './AuthReducer'

// Redux
export default combineReducers({
  Auth: AuthReducer,
})
