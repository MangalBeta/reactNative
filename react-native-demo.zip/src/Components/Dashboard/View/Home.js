import React, { Component } from 'react'

import {
  View,
  ImageBackground,
  Image,
  TouchableOpacity,
  Text,
  ActivityIndicator,
} from 'react-native'
import Icon from 'react-native-vector-icons/FontAwesome';
import Header from '../../../Common/Header'
class Home extends Component {
  constructor(props) {
    super(props)
    this.state = {
    }
  }
  leftComponent(){
    return(
      <Text>Left</Text>
     )
  }
  render() {
    return (
      <View style={{
        flex: 1,
        backgroundColor: 'white', justifyContent: 'center', alignContent: 'center',
      }}>
        <Header title="Home"/>
        <View style={{ flex: 1, justifyContent: 'center', alignContent: 'center', }}>
           <Text style={{ alignSelf:'center'}}>Hello Home </Text>
        </View>
      </View>
    );
  }
}

export default Home
