import React, { Component } from "react";
import { Share } from 'react-native';
const deviceHeight = Dimensions.get("window").height;
const deviceWidth = Dimensions.get("window").width;

import { bindActionCreators } from 'redux';
import { logOutUser } from '../Actions/AuthAction';
import { connect } from 'react-redux';


import { Image, Platform, Dimensions, View } from "react-native";


const datas = [
  {
    name: "Home",
    route: "HomeNavigation",
    icon: "home",
    bg: "#013e7b"
  },

];

class SideBar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      shadowOffsetWidth: 1,
      shadowRadius: 4,
      userName: '',
      result: ''
    };
  }
  componentWillMount() {
   
  }

  logOutUser() {
   // this.props.logOutUser();
   // this.props.navigation.navigate('Auth');
  }
  logInUserNavigate() {
  //  this.props.navigation.navigate('Auth');
  }
  render() {
    return (

      <View style={{ flex: 1, backgroundColor: "#013e7b" }}>

      
      </View>
    );
  }
}

function mapStateToProps(state) {
  return {
    user: state.Auth.user

  }
}
//mapping dispatcheable actions to component
const  mapDispathToProps = (dispatch) => {
  return bindActionCreators({ logOutUser  }, dispatch);
}
export default connect(mapStateToProps, mapDispathToProps)(SideBar)

const styles = {
  drawerImage: {
    height: 35,
    resizeMode: Image.resizeMode.contain,
    // position: "absolute",
    right: Platform.OS === "android" ? deviceWidth / 12 : deviceWidth / 10,
    marginTop: 20
    //top: Platform.OS === "android" ? 20 : 10,
    // width: 210,
    //  height: 25,
    //  resizeMode: "cover",

  },
  text: {
    fontWeight: Platform.OS === "ios" ? "500" : "400",
    fontSize: 16,
    marginLeft: 20,
    color: '#fff'
  },
  badgeText: {
    fontSize: Platform.OS === "ios" ? 13 : 11,
    fontWeight: "400",
    textAlign: "center",
    marginTop: Platform.OS === "android" ? -3 : undefined
  }
};

