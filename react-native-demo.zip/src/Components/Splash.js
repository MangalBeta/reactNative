import React, { Component } from 'react'

import {
  View,
  Text,
  ImageBackground,
  Image,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native'

class Splash extends Component {
  constructor(props){
    super(props)
  }
  componentDidMount(){
    setTimeout(() => this.props.navigation.navigate('Auth'),500)
  }
  render() {
    return (
        <View style={{ flex: 1 ,
          backgroundColor: '#03A9F4',justifyContent: 'center', alignContent: 'center',}}>
            <Text style={{fontSize:24,color:'#fff',alignSelf:'center'}}>Splash Screen</Text>
        </View>

    );
  }
}

export default Splash
