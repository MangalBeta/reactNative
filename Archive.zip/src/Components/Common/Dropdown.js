import React, { Component } from 'react';
import {
    View, Text, TextInput, Image, Dimensions, ScrollView, StyleSheet,
    KeyboardAvoidingView, Switch
} from 'react-native';
const { width, height } = Dimensions.get('window')
import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome'
import Entypo from 'react-native-vector-icons/Entypo'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import RNPickerSelect from 'react-native-picker-select';

class Dropdown extends Component {
    constructor() {
        super();
        this.state = {
            condition: "",
            items:[]
        }
    }
    componentWillMount(){
       (this.props.data)?
       this.setState({items:this.props.data}):null
    }
     componentWillRecieve(nextProps){
         (nextProps)
     }
    render() {
        return (
            <View style={{ borderColor: '#828181',
            marginBottom: 10,
            paddingTop: 10,
            height:40,
            paddingHorizontal: 10,borderWidth:2}}>
                <RNPickerSelect
                    placeholder={{
                        label: this.props.label,
                        value: null,
                    }}
                    items={this.state.items}
                    onValueChange={
                        (item) => {
                            this.setState({
                                condition: item.value,
                            });
                        }
                    }
                    //onUpArrow={() => { this.inputRefs.name.focus(); }}
                    //onDownArrow={() => { this.inputRefs.picker2.togglePicker(); }}
                  hideIcon={true}
                    value={this.state.condition}
                //ref={(el) => {
                //    this.inputRefs.picker = el;
                //}}
                />
            </View>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    label: { fontSize: 18, color: '#000', fontWeight: 'bold' },
    iconView: { flex: 1, paddingVertical: 40, marginLeft: 10 },
    inputView: {
        height: 45, marginTop: 10,
        // backgroundColor: '#DCD7D7',
        borderRadius: 5,
    },
    image: { width: width - 40, height: height / 4 },

});

//make this component available to the app
export default Dropdown;