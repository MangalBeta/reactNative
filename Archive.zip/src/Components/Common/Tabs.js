import React, { Component } from 'react';
import {
    View, Image, Dimensions, ScrollView, Button, StyleSheet, TouchableOpacity,
    KeyboardAvoidingView
} from 'react-native';
import { Text } from 'react-native-elements'
const { width, height } = Dimensions.get('window')
import { StackNavigator, DrawerNavigator } from 'react-navigation';
import Icon from 'react-native-vector-icons/FontAwesome'

//Import component
class Tabs extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: ``,
    });
    constructor() {
        super();
        this.state = {
            checked: false,
            indexItem: -1,
            active: false
        }
    }
    renderTabView() {
        return this.props.TabsArr.map((tabImg, index) => {
            return (

                <View style={styles.tabview} key={index}>
                    <TouchableOpacity onPress={() => this.setState({
                        indexItem: index,
                    })}>
                        {this.state.indexItem == index ?
                            <View>
                                <Image source={tabImg}
                                    style={{ width: 48, height: 48, alignSelf: 'center' }}
                                    resizeMode="contain" />
                            </View>

                            : <Image source={tabImg}
                                style={{ width: 48, height: 48, alignSelf: 'center' }}
                                resizeMode="contain" />
                        }

                    </TouchableOpacity >

                </View>

            )
        })
    }
    render() {
        return (
            <View style={styles.cardView4}>
            {this.renderTabView()}
            </View>
        )
    }
}

// define your styles
const styles = StyleSheet.create({
    tabview: { flex: 1, padding: 10 },
    cardView4: {
        position: 'absolute', bottom: 0, left: 0, right: 0, height: 65,
        // render global persistent stuff here 
        // backgroundColor: 'whitesmoke',
        flexDirection: 'row',
        // flex:-1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#524B48',
        // // marginTop:(height+80)-height

    },
   
});

//make this component available to the app
export default Tabs;
