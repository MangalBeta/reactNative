import React, { Component } from 'react';
import { View,TouchableOpacity, Text, Image, Button,StyleSheet, Dimensions

     } from 'react-native';
import MenuBar from '../../Assets/menubar.png'
import Icon from 'react-native-vector-icons/FontAwesome'

import {Header}from 'react-native-elements'
import AppLogo from '../../Assets/logo2x.png'
const {width,height}  =  Dimensions.get('window')
// create a component
class HeaderComponent extends Component {

    leftComponent = () => {
        return( this.props.sidebar ? <TouchableOpacity onPress={() =>
            this.props.leftIcon == 'arrow-left' ? this.props.goBack() :
        this.props.navigateClick()
        }>
           <Icon name={this.props.leftIcon}  size={28} color={'#fff'}/>
           </TouchableOpacity>  : null
           )
    }
    rightComponent = () => {
        return (
            <TouchableOpacity onPress={() =>this.props.openScreen()}>
            <Icon name={this.props.rightIcon}  size={28} color={this.props.color}/>
        </TouchableOpacity>
        )
    }
    centerComponent = () => {
        return (
         this.props.title ? { text: this.props.title, style: {
             color: '#fff',fontSize:22 ,fontWeight:'bold'} }: 
        <Image resizeMode="contain" style={styles.logo} 
        source={AppLogo} />
    )

    }
    render() {
        console.log(this.props,"hbhjjj")
        return (
            <Header
            leftComponent={this.leftComponent()}
            centerComponent={this.centerComponent() }
            rightComponent={this.rightComponent()}
            backgroundColor={"#524B48"}
          />
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    logo :{
        width:width/2,
        flex:1
    }
})

//make this component available to the app
export default HeaderComponent;
