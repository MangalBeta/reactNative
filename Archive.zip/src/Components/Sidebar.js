import React, { Component } from 'react';
import { NavigationActions } from 'react-navigation';
import { ScrollView, Text, Image, View } from 'react-native';

import ArrowIcon from '../Assets/rightarrow.png'
import SettingIcon from '../Assets/settingnew.png'
import MoreInfo from '../Assets/more_info_icon.png'

class SideMenu extends Component {
    navigateToScreen = (route) => () => {
        const navigateAction = NavigationActions.navigate({
            routeName: route
        });
        this.props.navigation.dispatch(navigateAction);
    }

    render() {
        return (
            <View style={styles.container}>
                <ScrollView>
                    <View >
                        <View style={{ flexDirection: 'row', }}>
                            <Image source={SettingIcon}
                                resizeMode='contain'
                                style={styles.sectionImg} />
                            <View>

                                <Text style={styles.sectionHeadingStyle}>
                                    SETTINGS
                         </Text>
                            </View>

                        </View>
                        <View style={styles.navSectionStyle}>
                            <View style={styles.rowSec}>
                                <View style={{ flex: 0.9 }}>

                                    <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Configuration')}>
                                        Configuration
                           </Text>
                                </View>
                                <View style={{ flex: 0.2, alignItems: 'center', justifyContent: 'center' }}>
                                    <Image source={ArrowIcon}
                                        resizeMode='contain'
                                        style={styles.imgaeRight} />
                                </View>

                            </View>
                            <View style={styles.rowSec}>
                                <View style={{ flex: 0.9 }}>

                                    <Text style={styles.navItemStyle} onPress={this.navigateToScreen('RecycleBin')}>
                                        Recycle Bin
</Text>
                                </View>
                                <View style={{ flex: 0.2, alignItems: 'center', justifyContent: 'center' }}>

                                    <Image source={ArrowIcon}
                                        resizeMode='contain'
                                        style={styles.imgaeRight} />
                                </View>

                            </View>
                            <View style={styles.rowSec}>
                                <View style={{ flex: 0.9 }}>

                                    <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Filter')}>
                                        Filter

                           </Text>
                                </View>
                                <View style={{ flex: 0.2, alignItems: 'center', justifyContent: 'center' }}>

                                    <Image source={ArrowIcon}
                                        resizeMode='contain'
                                        style={styles.imgaeRight} />
                                </View>

                            </View>
                            <View style={styles.rowSec}>
                                <View style={{ flex: 0.9 }}>

                                    <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Page1')}>
                                        Logout
                                </Text>
                                </View>
                                <View style={{ flex: 0.2, alignItems: 'center', justifyContent: 'center' }}>

                                    <Image source={ArrowIcon}
                                        resizeMode='contain'
                                        style={styles.imgaeRight} />
                                </View>

                            </View>
                        </View>
                    </View>
                    <View>
                        <View style={{ flexDirection: 'row' }}>
                            <Image source={MoreInfo}
                                resizeMode='contain'
                                style={styles.sectionImg} />
                            <Text style={styles.sectionHeadingStyle}>
                                MORE INFORMATION
                         </Text>
                        </View>
                        <View style={styles.navSectionStyle}>
                            <View style={styles.rowSec}>
                                <View style={{ flex: 0.9 }}>

                                    <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Page1')}>
                                        Privacy Policy
                                </Text>
                                </View>
                                <View style={{ flex: 0.2, alignItems: 'center', justifyContent: 'center' }}>

                                    <Image source={ArrowIcon}
                                        resizeMode='contain'
                                        style={styles.imgaeRight} />
                                </View>
                            </View>
                            <View style={styles.rowSec}>
                                <View style={{ flex: 0.9 }}>

                                    <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Page1')}>
                                        Terms Of Use</Text>
                                </View>
                                <View style={{ flex: 0.2, alignItems: 'center', justifyContent: 'center' }}>

                                    <Image source={ArrowIcon}
                                        resizeMode='contain'
                                        style={styles.imgaeRight} />
                                </View>
                            </View><View style={styles.rowSec}>
                                <View style={{ flex: 0.9 }}>

                                    <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Page1')}>
                                        Help</Text>
                                </View>
                                <View style={{ flex: 0.2, alignItems: 'center', justifyContent: 'center' }}>

                                    <Image source={ArrowIcon}
                                        resizeMode='contain'
                                        style={styles.imgaeRight} />
                                </View>
                            </View>
                            <View style={styles.rowSec}>
                                <View style={{ flex: 0.9 }}>

                                    <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Page1')}>
                                        About Us
                                </Text>
                                </View>
                                <View style={{ flex: 0.2, alignItems: 'center', justifyContent: 'center' }}>

                                    <Image source={ArrowIcon}
                                        resizeMode='contain'
                                        style={styles.imgaeRight} />
                                </View>
                            </View>
                        </View>
                    </View>
                </ScrollView>
                {/* <View style={styles.footerContainer}>
                </View> */}
            </View>
        );
    }
}

const styles = {
    sectionImg: {
        width: 28, height: 28, alignSelf: 'center', paddingHorizontal: 20
    },
    rowSec: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    imgaeRight: {
        width: 15,
        height: 15,
        alignSelf: 'center'
    },
    container: {
        paddingTop: 20,
        flex: 1
    },
    navItemStyle: {
        padding: 10,
        marginLeft:50,
        fontSize: 18,
        color: '#fff',
        alignSelf: 'flex-start'
    },
    navSectionStyle: {
        // backgroundColor: 'lightgrey',
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    sectionHeadingStyle: {
        paddingVertical: 10,
        paddingHorizontal: 5,
        fontSize: 20,
        fontWeight:'bold',
        color: '#fff'
    },
    footerContainer: {
        padding: 20,
        backgroundColor: 'lightgrey'
    }
};


export default SideMenu;
