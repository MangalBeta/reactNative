import React, { Component } from 'react';
import {
    View, Text, TextInput, Image, Dimensions, ScrollView, StyleSheet,
    KeyboardAvoidingView, Switch, TouchableOpacity,
} from 'react-native';
const { width, height } = Dimensions.get('window')
import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome'
import Entypo from 'react-native-vector-icons/Entypo'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import Dropdown from '../../Common/Dropdown'
import Switches from '../../Common/Switch'
import CameraIcon from '../../../Assets/camera-48.png'
import DbIcon from '../../../Assets/database-48.png'
import BoxIcon from '../../../Assets/box-48.png'
import close from '../../../Assets/x-48.png'

//Import component
import Header from '../../Common/Header'
import TabView from '../../Common/Tabs'
const TabsArr = [BoxIcon, DbIcon, CameraIcon]

// create a component
class Filter extends Component {
    constructor() {
        super();
        this.state = {
            quantity: 0,
            condition: true,
            value: 0,
            items: [
                {
                    label: 'Good',
                    value: 'Good',
                },
                {
                    label: 'Excellent',
                    value: 'Excellent',
                },
                {
                    label: 'Poor',
                    value: 'Poor',
                },
            ],
        }
    }
    render() {
        return (

            <View style={[styles.container, { flex: 1 }]}>
                <Header
                    leftIcon='home'
                    rightIcon='filter'
                    color={'white'}
                    sidebar={true}
                    goBack={this.props.navigation.goBack} 
                    openScreen = {() => this.props.navigation.navigate('')}
                    navigateClick={() => this.props.navigation.navigate('Dashboard')} />
                <ScrollView style={{marginBottom:65,backgroundColor:'white'}}>
                <View style={[{ flex: 1, padding: 20 }]}>
                    {/*<KeyboardAvoidingView>*/}
                    <View style={{
                        flexDirection: 'row', borderColor: '#000', borderWidth: 2,
                        marginBottom: 10,backgroundColor:'#CCCCCC'
                    }}>
                        <View style={{ flex: 6, paddingRight: 10 ,}}>
                            <TextInput placeholder="Search"
                                underlineColorAndroid={"transparent"}
                                numberOfLines={3}
                                multiline={true}
                                style={{
                                    paddingLeft: 10, textAlignVertical: "center",
                                    height: 65
                                }} editable={true} />
                        </View>
                        <View style={{ flex: 1, justifyContent: "center", alignItems: 'center', paddingRight: 10 }}>
                          <TouchableOpacity onPress={() => this.props.navigation.navigate('FindAsset')}>
                                <Icon name={'search'} color={'#000'} size={36} />
                                </TouchableOpacity>
                            {/* <Image source={Search}
                            style={{ alignSelf: 'center', width: 50, height: 50, }}
                            resizeMode="contain" /> */}
                        </View>
                    </View>
                    <View style={styles.switchContainer}>
                        <Text style={styles.label}>Search only in Package</Text>
                        <Switches />
                    </View>
                    <View style={styles.switchContainer}>
                        <Text style={styles.label}>Search only in Punch List</Text>
                        <Switches />
                    </View>
                    <View style={{ marginBottom: 10, marginTop:10,
                        flexDirection: 'row',borderColor: '#828181', borderBottomWidth: 2, }}>
                        <View style={{flex:8, }}>
                            <TextInput
                                placeholder="Mask"
                                underlineColorAndroid={"transparent"}
                                style={{ padding: 5,paddingLeft:0, fontSize: 18, }} editable={true} />
                        </View>
                        <View style={{flex:1}}>
                            <Image source={close}
                                style={{ alignSelf: 'center', width: 32, height: 32, }}
                                resizeMode="contain" />
                        </View>
                    </View>
                    <View style={{ marginBottom: 10 ,marginTop:10,}}>
                        <Text style={[styles.label,{ marginBottom: 5 }]}>Plant Section</Text>
                        <TextInput
                            placeholder=""
                            underlineColorAndroid={"transparent"}
                            style={{ padding: 10, borderColor: '#828181', borderWidth: 2, }} editable={true} />
                    </View>
                    <View style={{ marginBottom: 10 ,marginTop:10,}}>
                        <Text  style={[styles.label,{ marginBottom: 5 }]}>Critically</Text>
                        <Dropdown data={this.state.items} />
                    </View>
                    <View
                            style={{
                                flexDirection: 'row',
                                flex: 0.1,
                                paddingHorizontal: 10,
                                justifyContent: 'center',
                                alignItems: 'center'
                            }}>
                            <View style={{ flex: 1, flexDirection: 'row', marginTop: 20 }}>
                                <View style={{ flex: 0.5 }}  >
                                    <Button
                                        title="Cancel"
                                        titleStyle={{
                                            fontWeight: "700", fontSize: 22,
                                            color: '#000'
                                        }}
                                        buttonStyle={{
                                            backgroundColor: "#E69138",
                                            width: width / 3,
                                            height: 45,
                                            paddingVertical: 5,
                                            borderColor: "#000",
                                            borderWidth: 2,
                                            borderRadius: 5,
                                            shadowOffset: { width: 10, height: 10, },
                                            shadowColor: 'black',
                                            shadowOpacity: 0.4,
                                            elevation: 5
                                        }}
                                    //containerStyle={{ marginTop: 20 }}
                                    />
                                </View>
                                <View style={{ flex: 0.5 }} >
                                    <Button
                                        title="Save"
                                        titleStyle={{ fontWeight: "700", fontSize: 22, color: '#000' }}
                                        buttonStyle={{
                                            backgroundColor: "#E69138",
                                            width: width / 3,
                                            height: 45,
                                            borderColor: "#000",
                                            paddingVertical: 5,

                                            borderWidth: 2,
                                            borderRadius: 5,
                                            shadowOffset: { width: 10, height: 15, },
                                            shadowColor: 'black',
                                            shadowOpacity: 0.7,
                                            elevation: 5
                                        }}
                                    // containerStyle={{ marginTop: 20 }}
                                    />
                                </View>
                            </View>

                        </View>

                    {/*</KeyboardAvoidingView>*/}
                </View>
                </ScrollView>

                <TabView TabsArr={TabsArr} />

            </View>

        );
    }
}

// define your styles
const styles = StyleSheet.create({
    switchContainer: {
        marginBottom: 10,marginTop:10, flexDirection: 'row', justifyContent: 'space-between'
    },
    label: { fontSize: 16, color: '#000', fontWeight: '600' },
    iconView: { flex: 1, paddingVertical: 40, marginLeft: 10 },
    inputView: {
        height: 45, marginTop: 10,
        // backgroundColor: '#DCD7D7',
        borderRadius: 5,
    },
    image: { width: width - 40, height: height / 4 },

});

//make this component available to the app
export default Filter;