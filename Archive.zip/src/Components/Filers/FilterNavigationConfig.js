import React, { Component } from 'react';

import { StackNavigator } from 'react-navigation';

// import  component 
import Filter from './View/Filter';
import Configuration from './View/Configuration';

// Auth navigator
const Filternavigator = StackNavigator({
    Configuration: { screen: Configuration },

    Filter: { screen: Filter },


}, 
{
        initialRouteName: 'Configuration',
        headerMode: 'none',
      

    })



export default Filternavigator;