import React, { Component } from 'react';
import {
    View, Text, TextInput, Image, Dimensions, ScrollView, StyleSheet,
    KeyboardAvoidingView, Picker,TouchableOpacity
} from 'react-native';
const { width, height } = Dimensions.get('window')
import { StackNavigator, DrawerNavigator } from 'react-navigation';
import { Button } from 'react-native-elements';
import RNPickerSelect from 'react-native-picker-select';
import Icon from 'react-native-vector-icons/FontAwesome'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import Entypo from 'react-native-vector-icons/Entypo'
import { Dropdown } from 'react-native-material-dropdown';
// Import Images
import AppLogo from '../../../Assets/logo4x.png'
import MenuBar from '../../../Assets/menubar.png'
import ListTab from '../../../Assets/listtab2x.png'
import FindTab from '../../../Assets/findtab2x.png'
import CreateTab from '../../../Assets/createtab2x.png'
import AddIcon from '../../../Assets/plus-48.png'
import Search from '../../../Assets/noplanselectedicon.png'
import ArrowDown from '../../../Assets/arrow-48.png'

//Import component
import Header from '../../Common/Header'
// create a component
class AddAsset extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: ``,
    });
    constructor() {
        super();
        this.state = {
            quantity: 0,
            condition: '',
            items: [
                {
                    label: 'Good',
                    value: 'Good',
                },
                {
                    label: 'Excellent',
                    value: 'Excellent',
                },
                {
                    label: 'Poor',
                    value: 'Poor',
                },
            ]
        }
    }
    increament() {
        this.setState({ quantity: (this.state.quantity + 1) })
    }
    decreament() {
        if (this.state.quantity != 0) {
            this.setState({ quantity: (this.state.quantity - 1) })
        }
    }
    openDrawer() {
        this.props.navigate('DrawerOpen')
    }
    renderSaveIcon() {
        return <Image source={MenuBar} style={{ width: 28, height: 28 }} resizeMode="contain" />

    }
    render() {
        let data = [{
            value: 'Good',
        }, {
            value: 'Excellent',
        }, {
            value: 'Poor',
        }];
        return (
            <View style={[styles.container, { flex: 1 }]}>
                <Header
                    leftIcon='home'
                    color={'black'}
                    sidebar={true}
                    navigateClick={() => this.props.navigation.navigate('Dashboard')} />
                {/* View*/}
                <View style={[{ flex: 1, padding: 20 }]}>
                    <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Active Location</Text>
                    <View style={{
                        flexDirection: 'row', borderColor: '#000', borderWidth: 2,
                        marginBottom: 10
                    }}>
                        <View style={{ flex: 6, paddingRight: 10 }}>
                            <TextInput placeholder="Serach"
                                underlineColorAndroid={"transparent"}
                                numberOfLines={3}
                                multiline={true}
                                style={{ paddingLeft: 10, textAlignVertical: "center",
                                 height: 65 }} editable={true} />
                        </View>
                        <View style={{ flex: 1, justifyContent: "center", alignItems: 'center', paddingRight: 10 }}>
                         <TouchableOpacity onPress={() => this.props.navigation.navigate('SearchAsset')}>
                            <Icon name={'search'} color={'#FF9900'} size={36} />
                            {/* <Image source={Search}
                            style={{ alignSelf: 'center', width: 50, height: 50, }}
                            resizeMode="contain" /> */}
                            </TouchableOpacity>
                        </View>
                    </View>
                    <View style={{ marginTop: 5 }}>
                        <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Asset Name</Text>
                        <View style={{ flexDirection: 'row', marginBottom: 10 }}>
                            <View style={{ flex: 8, borderColor: '#000', borderWidth: 2, }}>
                                <TextInput placeholder="Serach" value="assets today 11aprail"
                                    style={{ padding: 10, textAlignVertical: "top" }} editable={false} />
                            </View>
                            <View style={{ flex: 1, justifyContent: "center",paddingLeft:5, alignItems: 
                            'center', }}>
                                  <Image source={ArrowDown}
                            style={{ alignSelf: 'center', width: 32, height: 32, }}
                            resizeMode="contain" />
                                {/* <Icon name="chevron-circle-down" size={32} /> */}
                            </View>
                            <View style={{ flex: 1, justifyContent: "center", alignItems: 'center', }}>
                                {/* <Entypo name="circle-with-plus" size={32} /> */}
                                   <Image source={AddIcon}
                            style={{ alignSelf: 'center', width: 32, height: 32, }}
                            resizeMode="contain" />
                            </View>
                        </View>
                    </View>
                    <View style={{ marginTop: 5 }}>
                        <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Description</Text>
                        <View style={{ borderColor: '#000', borderWidth: 2, }}>
                            <TextInput
                                placeholder="description"
                                underlineColorAndroid={"transparent"}
                                multiline={true}
                                numberOfLines={3}
                                style={{ padding: 5, height: 80, textAlignVertical: "top" }} editable={true} />
                        </View>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 20, }}>
                        <View style={{ alignItems: 'center', marginTop: 5 }}>
                            <Text style={{ fontSize: 16, color: '#000', }}>Quantity</Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ borderColor: '#000', paddingHorizontal: 60, borderWidth: 2, marginLeft: 10, justifyContent: 'center', alignItems: 'center' }}>
                                <Text style={{ fontSize: 16 }}>{this.state.quantity}</Text>
                            </View>
                        </View>
                        <View style={{ flexDirection: 'row', paddingHorizontal:1, borderWidth: 2, borderLeftWidth: 0, borderColor: '#000' }}>
                            <MaterialIcons name="arrow-drop-up" size={28} onPress={() => this.increament()} />
                            <MaterialIcons name="arrow-drop-down" size={28} onPress={() => this.decreament()} />
                        </View>
                    </View>
                    <View style={{ marginTop: 5 }}>
                        <Text style={{ fontSize: 16, color: '#000', }}>Condition</Text>
                    </View>
                    <View style={{
                        marginBottom: 10,
                        paddingVertical: 10,
                        marginTop: 5,
                        paddingHorizontal: 10,
                        height: 40,
                        borderColor: '#000', borderWidth: 2
                    }}>

                        <RNPickerSelect
                            placeholder={{
                                label: 'Select a color...',
                                value: this.state.condition,

                            }}

                            items={this.state.items}
                            onValueChange={
                                (item) => {
                                    this.setState({
                                        condition: item.value,
                                    });
                                }
                            }
                            //onUpArrow={() => { this.inputRefs.name.focus(); }}
                            //onDownArrow={() => { this.inputRefs.picker2.togglePicker(); }}
                            value={this.state.condition}
                            hideIcon={true}
                        //ref={(el) => {
                        //    this.inputRefs.picker = el;
                        />
                    </View>
                    <View style={{ marginTop: 10 }}>
                        <View style={{
                            justifyContent: 'center', borderColor: '#000',
                            borderWidth: 2, alignItems: 'center', backgroundColor: '#FF9900',
                            marginBottom: 10
                        }}>
                            <View style={{ flexDirection: 'row', padding: 10 }}>
                                <View style={{ marginRight: 5 }}>
                                    <Icon name="camera" size={28} color={"#000"} />
                                </View>
                                <View style={{ justifyContent: 'center' }}>
                                    <Text style={{ fontSize: 24, color: '#000' }}>ADD PHOTO</Text>
                                </View>
                            </View>
                        </View>
                        
                        <View style={{ justifyContent: 'center', borderColor: '#000', 
                        borderWidth: 2, alignItems: 'center', backgroundColor: '#CC0000' }}>
                            <View style={{ flexDirection: 'row', padding: 10 }}>
                                <View style={{ marginRight: 5 }}>
                                    <Icon name="warning" size={28} color={"#FFF"} />
                                </View>
                                <View style={{ justifyContent: 'center' }}>
                                    <Text style={{ fontSize: 24, color: '#FFF' }}>DEFECTS</Text>
                                </View>
                            </View>
                        </View>
                    </View>

                </View>
            </View>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    label: { fontSize: 18, color: '#000', fontWeight: 'bold' },
    iconView: { flex: 1, paddingVertical: 40, marginLeft: 10 },
    inputView: {
        height: 45, marginTop: 10,
        // backgroundColor: '#DCD7D7',
        borderRadius: 5,
    },
    image: { width: width - 40, height: height / 4 },
    inputIOS: {
        fontSize: 16,
        height: 40,
        paddingTop: 10,
        paddingHorizontal: 10,
        paddingBottom: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        backgroundColor: 'white',
    },


});

//make this component available to the app
export default AddAsset;
