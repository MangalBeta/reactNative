import React, { Component } from 'react';

import { StackNavigator } from 'react-navigation';

// import  component 
import AddAsset from './View/AddAsset';
import SearchAsset from './View/SearchAsset';
import CloneAsset from './View/CloneAsset';


// Auth navigator
const AddAssetnavigator = StackNavigator({
        AddAsset: { screen: AddAsset },
        SearchAsset: { screen: SearchAsset },
        CloneAsset: { screen: CloneAsset },


}, 
{
        initialRouteName: 'AddAsset',
        headerMode: 'none',
      

    })



export default AddAssetnavigator;