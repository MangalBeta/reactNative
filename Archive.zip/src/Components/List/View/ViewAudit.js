import React, { Component } from 'react';
import {
    View, TouchableOpacity, Text, TextInput, FlatList, Image, Dimensions, ScrollView, StyleSheet,
    KeyboardAvoidingView
} from 'react-native';
const { width, height } = Dimensions.get('window')
import { StackNavigator, DrawerNavigator } from 'react-navigation';
import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome'
// Import Images
import AppLogo from '../../../Assets/logo4x.png'
import MenuBar from '../../../Assets/menubar.png'
import ListTab from '../../../Assets/listtab2x.png'
import FindTab from '../../../Assets/findtab2x.png'
import CreateTab from '../../../Assets/createtab2x.png'
import AddIcon from '../../../Assets/addicon1.png'
import UploadImg from '../../../Assets/downlaods_icon2x.png'

//Import component
import Header from '../../Common/Header'
let data = [
    {
        Image: <Image source={UploadImg}
            style={{ width: 28, height: 28, alignSelf: 'center' }}
            resizeMode="contain" />
    },
    {
        Image: <Image source={UploadImg}
            style={{ width: 28, height: 28, alignSelf: 'center' }}
            resizeMode="contain" />
    },
    {
        Image: <Image source={UploadImg}
            style={{ width: 28, height: 28, alignSelf: 'center' }}
            resizeMode="contain" />
    },

]
// create a component
class ViewAudit extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: ``,
    });
    openDrawer() {
        this.props.navigate('DrawerOpen')
    }
    _renderItem = ({ item, index }) => {
        return (
            <TouchableOpacity>
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    marginTop: 10,
                }}>
                    <View style={{ flex: 1, justifyContent: 'center', marginRight: 10, backgroundColor: 'lightgrey', width: width / 3 - 13, height: height / 4 }}>
                        <Image source={UploadImg}
                            style={{ width: 28, height: 28, alignSelf: 'center' }}
                            resizeMode="contain" />
                    </View>
                </View>

            </TouchableOpacity>
        )

    }
    _keyExtractor = (item, index) => index + 'audits';

    render() {
        return (
            <View style={[{ flex: 1 }]}>
                <Header navigateClick={this.props.navigation.navigate}
                    sidebar={false}
                    rightBar={false}
                    title={'View Audits'} />
                <View style={styles.container}>

                    <FlatList
                        data={data}
                        style={{ flex: 1, }}
                        renderItem={this._renderItem}
                        horizontal={true}
                        keyExtractor={this._keyExtractor}
                        showsHorizontalScrollIndicator
                    />
                    <View style={{
                        flexDirection: 'row', justifyContent: 'center',
                        borderRadius: 5,
                        padding: 10, margin: 10, backgroundColor: '#ef6c0e', width: width - 20, alignItems: 'flex-end'
                    }}>
                        <Image source={UploadImg}
                            style={{ width: 28, height: 28, alignSelf: 'center', marginRight: 10 }}
                            resizeMode="contain" />
                        <Text style={{ color: '#FFF', fontSize: 18 }}>ADD PHOTO</Text>
                    </View>
                </View>
            </View>
        );
    }
}

// define your styles
const styles = StyleSheet.create({

    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f7f7f7',
        paddingHorizontal: 10
    },
});

//make this component available to the app
export default ViewAudit;
