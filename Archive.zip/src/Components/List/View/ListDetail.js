    import React, { Component } from 'react';
    import {
        View, Text, TextInput, Image, Dimensions, ScrollView, StyleSheet,
        KeyboardAvoidingView, Picker, TouchableOpacity
    } from 'react-native';
    const { width, height } = Dimensions.get('window')
    import { StackNavigator, DrawerNavigator } from 'react-navigation';
    import { Button } from 'react-native-elements';
    import RNPickerSelect from 'react-native-picker-select';
    import Icon from 'react-native-vector-icons/FontAwesome'
    import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
    import Entypo from 'react-native-vector-icons/Entypo'
    // Import Images
    import AppLogo from '../../../Assets/logo4x.png'
    import MenuBar from '../../../Assets/menubar.png'
    import ListTab from '../../../Assets/listtab2x.png'
    import FindTab from '../../../Assets/findtab2x.png'
    import CreateTab from '../../../Assets/createtab2x.png'
    import AddIcon from '../../../Assets/plus-48.png'
    import Search from '../../../Assets/noplanselectedicon.png'
    import ArrowDown from '../../../Assets/arrow-48.png'
    import Dropdown from '../../Common/Dropdown'
    import Switches from '../../Common/Switch'
    import UploadImg from '../../../Assets/assetDemo.jpg'

    //Import component
    import Header from '../../Common/Header'
    // create a component
    class AddAsset extends Component {
        static navigationOptions = ({ navigation }) => ({
            title: ``,
        });
        constructor() {
            super();
            this.state = {
                quantity: 0,
                condition: '',
                items: [
                    {
                        label: 'Good',
                        value: 'Good',
                    },
                    {
                        label: 'Excellent',
                        value: 'Excellent',
                    },
                    {
                        label: 'Poor',
                        value: 'Poor',
                    },
                ]
            }
        }
        increament() {
            this.setState({ quantity: (this.state.quantity + 1) })
        }
        decreament() {
            if (this.state.quantity != 0) {
                this.setState({ quantity: (this.state.quantity - 1) })
            }
        }
        openDrawer() {
            this.props.navigate('DrawerOpen')
        }
        renderSaveIcon() {
            return <Image source={MenuBar} style={{ width: 28, height: 28 }} resizeMode="contain" />

        }
        render() {
            let data = [{
                value: 'Good',
            }, {
                value: 'Excellent',
            }, {
                value: 'Poor',
            }];
            return (
                <View style={[styles.container, { flex: 1 }]}>
                    <Header
                    leftIcon='arrow-left'
                    color={'black'}
                        sidebar={true}
                        goBack={this.props.navigation.goBack} 
                        navigateClick={this.props.navigation.navigate} />
                    {/* View*/}
                    <ScrollView>
                        <View style={[{ flex: 1, padding: 15 }]}>
                            <View style={{justifyContent:'center'}}>
                                <Image source={UploadImg}
                                    style={{ alignSelf: 'center', height: height / 2-80, width: width-40}}
                                    resizeMode="contain" />
                            </View>
                            <View style={{ marginTop: 15 }}>
                                <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Asset Name</Text>
                                <View style={{ flexDirection: 'row', marginBottom: 10 }}>
                                    <View style={{ flex: 8, borderColor: '#000', borderWidth: 2, }}>
                                        <TextInput placeholder="Serach" value="SP168-B_TR1"
                                            style={{ padding: 10, textAlignVertical: "top" }} editable={false} />
                                    </View>
                                    <View style={{
                                        flex: 1, justifyContent: "center", paddingLeft: 5, alignItems:
                                            'center',
                                    }}>
                                        <Image source={ArrowDown}
                                            style={{ alignSelf: 'center', width: 32, height: 32, }}
                                            resizeMode="contain" />
                                        {/* <Icon name="chevron-circle-down" size={32} /> */}
                                    </View>
                                    <View style={{ flex: 1, justifyContent: "center", alignItems: 'center', }}>
                                        {/* <Entypo name="circle-with-plus" size={32} /> */}
                                        <Image source={AddIcon}
                                            style={{ alignSelf: 'center', width: 32, height: 32, }}
                                            resizeMode="contain" />
                                    </View>
                                </View>
                            </View>
                            <View style={{ marginTop: 5 }}>
                                <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Description</Text>
                                <View style={{ borderColor: '#000', borderWidth: 2, }}>
                                    <TextInput
                                        placeholder="description"
                                        underlineColorAndroid={"transparent"}
                                        multiline={true}
                                        value={'HANNANT A PORT (TR/1-1k VA)'}
                                        numberOfLines={3}
                                        style={{ padding: 5, height: 80, textAlignVertical: "top" }} editable={true} />
                                </View>
                            </View>
                            <View style={{ marginTop: 10 }}>
                                <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Parent</Text>
                                <View style={{ flexDirection: 'row', marginBottom: 10 }}>
                                    <View style={{ flex: 8, borderColor: '#000', borderWidth: 2, }}>
                                        <TextInput placeholder="Serach" value="Sp168"
                                            style={{ padding: 10, textAlignVertical: "top" }} editable={false} />
                                    </View>
                                    <View style={{
                                        flex: 1, justifyContent: "center", paddingLeft: 5, alignItems:
                                            'center',
                                    }}>
                                        <Image source={ArrowDown}
                                            style={{ alignSelf: 'center', width: 32, height: 32, }}
                                            resizeMode="contain" />
                                        {/* <Icon name="chevron-circle-down" size={32} /> */}
                                    </View>
                                    <View style={{ flex: 1, justifyContent: "center", alignItems: 'center', }}>
                                     <Icon name="search" size={32} color={'black'}/>

                                        {/* <Entypo name="circle-with-plus" size={32} /> */}
                                        {/* <Image source={AddIcon}
                                            style={{ alignSelf: 'center', width: 32, height: 32, }}
                                            resizeMode="contain" /> */}
                                    </View>
                                </View>
                            </View>
                            <View style={{ marginBottom: 10, marginTop:10,flexDirection: 'row', 
                            justifyContent: 'space-between' }}>
                                <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Upload Media</Text>
                                <Switches />
                            </View>
                            <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Active Location</Text>
                            <View style={{
                                flexDirection: 'row', borderColor: '#000', borderWidth: 2,
                                marginBottom: 10
                            }}>
                                <View style={{ flex: 6, paddingRight: 10 }}>
                                    <TextInput placeholder="Serach"
                                        underlineColorAndroid={"transparent"}
                                        numberOfLines={3}
                                        multiline={true}
                                        value={'CE Combustion Rngineers Class'}
                                        style={{
                                            paddingLeft: 10, textAlignVertical: "center",
                                            height: 65
                                        }} editable={true} />
                                </View>
                                <View style={{ flex: 1, justifyContent: "center", alignItems: 'center', paddingRight: 10 }}>
                                    <TouchableOpacity onPress={() => this.props.navigation.navigate('')}>
                                        <Icon name={'search'} color={'#FF9900'} size={36} />
                                        {/* <Image source={Search}
                                style={{ alignSelf: 'center', width: 50, height: 50, }}
                                resizeMode="contain" /> */}
                                    </TouchableOpacity>
                                </View>
                            </View>
                            <View>
                                <View style={{ marginTop: 5,marginBottom:5 }}>
                                    <Text style={{ fontSize: 16, color: '#000', }}>Condition</Text>
                                </View>
                                <Dropdown data={this.state.items} label={'Select a Condition'}/>
                            </View>
                            <View>
                                <View style={{ marginTop: 5,marginBottom:5 }}>
                                    <Text style={{ fontSize: 16, color: '#000', }}>Asset Type</Text>
                                </View>
                                <Dropdown data={this.state.items} label={'Select a Assert Type'}/>
                            </View>
                            <View>
                                <View style={{ marginTop: 5 ,marginBottom:5}}>
                                    <Text style={{ fontSize: 16, color: '#000', }}>Cylinder Configuration</Text>
                                </View>
                                <Dropdown data={this.state.items} label={'Select a Cylinder Configuration'}/>
                            </View>
                            <View>
                                <View style={{ marginTop: 5 ,marginBottom:5}}>
                                    <Text style={{ fontSize: 16, color: '#000', }}>Power - design</Text>
                                </View>
                                <Dropdown data={this.state.items} label={'Select a Power Design'}/>
                            </View>

                            <View style={{ marginTop: 10 }}>
                                <View style={{
                                    justifyContent: 'center', borderColor: '#000',
                                    borderWidth: 2, alignItems: 'center', backgroundColor: '#FF9900',
                                    marginBottom: 10
                                }}>
                                    <TouchableOpacity>
                                        <View style={{ flexDirection: 'row', padding: 10 }}>
                                            <View style={{ marginRight: 5 }}>
                                                <Icon name="camera" size={28} color={"#000"} />
                                            </View>
                                            <View style={{ justifyContent: 'center' }}>
                                                <Text style={{ fontSize: 24, color: '#000' }}>ADD PHOTO</Text>
                                            </View>
                                        </View>
                                    </TouchableOpacity>

                                </View>
                                <View style={{
                                    justifyContent: 'center', borderColor: '#000',
                                    borderWidth: 2, alignItems: 'center', backgroundColor: '#FF9900',
                                    marginBottom: 10
                                }}>
                                    <TouchableOpacity>
                                        <View style={{ flexDirection: 'row', padding: 10 }}>
                                            <View style={{ marginRight: 5 }}>
                                                <Icon name="database" size={28} color={"#000"} />
                                            </View>
                                            <View style={{ justifyContent: 'center' }}>
                                                <Text style={{ fontSize: 24, color: '#000' }}>DATABASE SAVE</Text>
                                            </View>
                                        </View>
                                    </TouchableOpacity>

                                </View>
                                <View style={{
                                    justifyContent: 'center', borderColor: '#000',
                                    borderWidth: 2, alignItems: 'center', backgroundColor: '#FF9900',
                                    marginBottom: 10
                                }}>
                                    <TouchableOpacity>
                                        <View style={{ flexDirection: 'row', padding: 10 }}>
                                            <View style={{ marginRight: 5 }}>
                                                <Icon name="paperclip" size={28} color={"#000"} />
                                            </View>
                                            <View style={{ justifyContent: 'center' }}>
                                                <Text style={{ fontSize: 24, color: '#000' }}>ATTACHMENTS</Text>
                                            </View>
                                        </View>
                                    </TouchableOpacity>

                                </View>

                                <View style={{
                                    marginBottom: 10,
                                    justifyContent: 'center', borderColor: '#000',
                                    borderWidth: 2, alignItems: 'center', backgroundColor: '#CC0000'
                                }}>
                                    <TouchableOpacity>

                                        <View style={{ flexDirection: 'row', padding: 10 }}>
                                            <View style={{ marginRight: 5 }}>
                                                <Icon name="warning" size={28} color={"#FFF"} />
                                            </View>
                                            <View style={{ justifyContent: 'center' }}>
                                                <Text style={{ fontSize: 24, color: '#FFF' }}>DEFECTS</Text>
                                            </View>
                                        </View>
                                    </TouchableOpacity>

                                </View>
                                <View style={{
                                    justifyContent: 'center', borderColor: '#000',
                                    borderWidth: 2, alignItems: 'center', backgroundColor: '#FF9900',
                                    marginBottom: 10
                                }}>
                                    <TouchableOpacity>
                                        <View style={{ flexDirection: 'row', padding: 10 }}>
                                            <View style={{ marginRight: 5 }}>
                                                <Icon name="clone" size={28} color={"#000"} />
                                            </View>
                                            <View style={{ justifyContent: 'center' }}>
                                                <Text style={{ fontSize: 24, color: '#000' }}>CLONE</Text>
                                            </View>
                                        </View>
                                    </TouchableOpacity>

                                </View>
                                <View style={{
                                    justifyContent: 'center', borderColor: '#000',
                                    borderWidth: 2, alignItems: 'center', backgroundColor: '#CC0000'
                                }}>
                                    <TouchableOpacity>

                                        <View style={{ flexDirection: 'row', padding: 10 }}>
                                            <View style={{ marginRight: 5 }}>
                                                <Icon name="trash" size={28} color={"#FFF"} />
                                            </View>
                                            <View style={{ justifyContent: 'center' }}>
                                                <Text style={{ fontSize: 24, color: '#FFF' }}>DELETE</Text>
                                            </View>
                                        </View>
                                    </TouchableOpacity>

                                </View>
                            </View>

                        </View>
                    </ScrollView>

                </View>
            );
        }
    }

    // define your styles
    const styles = StyleSheet.create({
        label: { fontSize: 18, color: '#000', fontWeight: 'bold' },
        iconView: { flex: 1, paddingVertical: 40, marginLeft: 10 },
        inputView: {
            height: 45, marginTop: 10,
            // backgroundColor: '#DCD7D7',
            borderRadius: 5,
        },
        image: { width: width - 40, height: height / 4 },
        inputIOS: {
            fontSize: 16,
            height: 40,
            paddingTop: 10,
            paddingHorizontal: 10,
            paddingBottom: 10,
            borderWidth: 1,
            borderColor: 'gray',
            borderRadius: 4,
            backgroundColor: 'white',
        },


    });

    //make this component available to the app
    export default AddAsset;
