import React, { Component } from 'react';

import { StackNavigator } from 'react-navigation';

// import  component 
import List from './View/List';
import ListDetail from './View/ListDetail';
import ViewAudit from './View/ViewAudit';
import FindAsset from './View/FindAsset';

// Auth navigator
const Listnavigator = StackNavigator({
        List: { screen: List },
        ListDetail: { screen: ListDetail },
        ViewAudit: { screen: ViewAudit },
        FindAsset: { screen: FindAsset },


}, 
{
        initialRouteName: 'List',
        headerMode: 'none',
      

    })



export default Listnavigator;