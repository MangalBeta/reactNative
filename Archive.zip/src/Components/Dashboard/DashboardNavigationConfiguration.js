import React, { Component } from 'react';

import { StackNavigator } from 'react-navigation';

// import  component 
import Home from './View/Home';

// Auth navigator
const Dashboardavigator = StackNavigator({
        Home: { screen: Home },
        


}, 
{
        initialRouteName: 'Home',
        headerMode: 'none',
      

    })



export default Dashboardavigator;