import React, { Component } from 'react';
import {
    FlatList,
    View, Text, TextInput, Image, Dimensions, ScrollView, StyleSheet,
    KeyboardAvoidingView, TouchableOpacity
} from 'react-native';
const { width, height } = Dimensions.get('window')
import { CheckBox } from 'react-native-elements'

import { StackNavigator, DrawerNavigator } from 'react-navigation';
import { Button } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import Entypo from 'react-native-vector-icons/Entypo'
// Import Images
import AppLogo from '../../../Assets/logo4x.png'
import MenuBar from '../../../Assets/menubar.png'
import ListTab from '../../../Assets/listtab2x.png'
import FindTab from '../../../Assets/findtab2x.png'
import CreateTab from '../../../Assets/createtab2x.png'
import AddIcon from '../../../Assets/addicon1.png'
import UploadImg from '../../../Assets/assetDemo.jpg'

import Search from '../../../Assets/noplanselectedicon.png'

//Import component
import Header from '../../Common/Header'
import Dropdown from '../../Common/Dropdown'

let data = [
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Valve" },
    { name: "PA-10823", description: "Pump" },
    { name: "PA-10823", description: "Pump" },
]

// create a component
class RecycleBin extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: ``,
    });
    constructor() {
        super();
        this.state = {
            checked: false,
            items: [
                {
                    label: 'Good',
                    value: 'Good',
                },
                {
                    label: 'Excellent',
                    value: 'Excellent',
                },
                {
                    label: 'Poor',
                    value: 'Poor',
                },
            ]
        }
    }
    // openDrawer() {
    //     this.props.navigate('DrawerOpen')
    // }
    _renderItem = ({ item, index }) => {
        return (
            <TouchableOpacity>
                <View style={(index % 2 === 0) ? styles.lisBack : styles.listColor}>
                    <View style={{ flex: 0.2, paddingHorizontal: 5, }}>
                    <CheckBox
                            checkedIcon='dot-circle-o'
                            uncheckedIcon='circle-o'
                         checkedColor={'black'}
                            
                        onPress={() => this.setState({ checked: !this.state.checked })}
                         containerStyle={{ 
                            borderWidth: 0,
                         borderRadius: 0 ,width:45,
                         marginLeft:-5,
                         backgroundColor:'transparent'}}
                        checked={this.state.checked} />
                    </View>
                    <View style={{ flex: 1, justifyContent: 'center', borderRightWidth: 1, borderLeftWidth: 1, borderColor: 'black', paddingHorizontal: 5, }}>
                        <Text style={{ color: '#000', fontSize: 16 }}>{item.name}</Text>
                    </View>
                    <View style={{ flex: 1, paddingHorizontal: 5, justifyContent: 'center' }}>
                        <Text style={{ color: '#000', fontSize: 16 }}>{item.description}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        )

    }
    _keyExtractor = (item, index) => index + 'reycle';
    render() {

        return (
            <View style={[{ flex: 1 }]}>
                <Header
                    leftIcon='bars'
                    // rightIcon='filter'
                    color={'#fff'}
                    sidebar={true}
                    openScreen={() => console.log()}

                    navigateClick={this.props.navigation.navigate}
                />
                {/* View*/}

                <View style={styles.container}>
                    <View style={{ marginTop: 15 }}>
                        <Text style={{ fontSize: 16, color: '#000', padding: 0 }}>Object</Text>
                    </View>
                    <View style={{ flexDirection: 'row', marginTop: 10 }}>

                        <View style={{ flex: 8, }}>
                            <Dropdown data={this.state.items} label={'Select Asset'} />
                        </View>
                        <View style={{
                            flex: 1, justifyContent: "center", paddingLeft: 5, alignItems:
                                'center'
                        }}>
                            <Icon name="trash" size={32} />
                        </View>

                    </View>
                    <View style={{
                        flexDirection: 'row', borderColor: 'black',
                        borderRadius: 20,
                        borderWidth: 2, marginBottom: 15, marginTop: 10
                    }}>
                        <View style={{ flex: 1, justifyContent: "center", alignItems: 'center', paddingRight: 10 }}>
                            <Icon name={'search'} color={'black'} size={28} />
                        </View>
                        <View style={{ flex: 6, paddingRight: 0 }}>
                            <TextInput placeholder="Serach"
                                underlineColorAndroid={"transparent"}
                                style={{
                                    textAlignVertical: "top", height: 40
                                }} editable={true} />
                        </View>

                    </View>
                    <View style={{ flex: 1, borderColor: 'black', borderWidth: 2 }}>
                        {/* <View style={{flexDirection:'row'}}>
                          <View style={{backgroundColor:'red',height:100}}>
                          <Text>1dsfds</Text>
                              </View>
                              <View style={{backgroundColor:'green',height:100}}>
                              <Text>1dsfds</Text>
                              </View>
                              <View style={{backgroundColor:'orange',height:100}}>
                              <Text>1dsfds</Text>
                              </View>

                              </View> */}
                        <View style={{ flexDirection: 'row', backgroundColor: '#CCCCCC' }}>
                            <View style={{ flex:0.2, paddingHorizontal: 5 }}>
                            <CheckBox
                            checkedIcon='dot-circle-o'
                            uncheckedIcon='circle-o'
                         checkedColor={'black'}
                            
                        onLongPress={() => this.setState({ checked: !this.state.checked })}
                        containerStyle={{ 
                            borderWidth: 0,
                         borderRadius: 0 ,width:45,
                         marginLeft:-5,
                         backgroundColor:'transparent'}}
                        checked={this.state.checked} />
                              
                            </View>
                            <View style={{ flex: 1, borderRightWidth: 1, justifyContent: 'center', borderLeftWidth: 1, borderColor: 'black', paddingHorizontal: 5, }}>
                                <Text style={{ color: '#000', fontSize: 16 }}>Name</Text>
                            </View>
                            <View style={{ flex: 1, paddingHorizontal: 5, justifyContent: 'center' }}>
                                <Text style={{ color: '#000', fontSize: 16 }}>Description</Text>
                            </View>
                        </View>
                        <FlatList
                            data={data}
                            keyExtractor={this._keyExtractor}
                            style={{
                                flex: 1,
                                padding: 0
                            }}
                            renderItem={this._renderItem}
                        />
                    </View>
                    <View style={{ flex: 0.2, marginTop: 20, marginBottom: 10, }}>
                        <View style={{
                            flexDirection: 'row',
                            borderColor: '#000',
                            justifyContent: 'center',
                            alignItems: 'center',
                            borderWidth: 2,
                            alignItems: 'center',
                            backgroundColor: '#E69138',
                            borderRadius: 2,
                            shadowOffset: { width: 10, height: 2, },
                            shadowColor: 'black',
                            shadowOpacity: 0.6,
                            elevation: 5
                        }}>
                            <View style={{ flexDirection: 'row', padding: 10 }}>
                                <View style={{ marginRight: 5 }}>
                                    <Icon name="refresh" size={28} color={"#000"} />
                                </View>
                                <View style={{ justifyContent: 'center' }}>
                                    <Text style={{ fontSize: 24, color: '#000' }}>RESTORE</Text>
                                </View>
                            </View>
                        </View>
                    </View>


                </View>
            </View>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 2,
        // justifyContent: 'center',
        // alignItems: 'center',
        backgroundColor: '#f7f7f7',
        paddingHorizontal: 10,
        marginTop: 10,
        paddingHorizontal:15
    },
    lisBack: {

        backgroundColor: '#eeeeee', flex: 1, flexDirection: 'row'
    },
    listColor: {

        backgroundColor: '#FFF', flex: 1, flexDirection: 'row'
    },

    inputView: {
        height: 45, marginTop: 10,

    },
    cardView4: {
        position: 'absolute',
        bottom: 0, left: 0, right: 0, height: 50,
        // render global persistent stuff here 
        backgroundColor: 'whitesmoke',
        flexDirection: 'row',
        // flex:-1,
        justifyContent: 'center',
        alignItems: 'center',

    },
    tabText: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#fff',
        alignSelf: 'center'
    },
    buttonStyle: {
        justifyContent: 'center', alignItems: 'center', backgroundColor: 'orange',
        marginBottom: 10,
        paddingTop: 5,
        paddingBottom: 5,
        borderColor: "black",
        borderWidth: 2,
        borderRadius: 2,
        shadowOffset: { width: 10, height: 10, },
        shadowColor: 'black',
        shadowOpacity: 0.2,
        elevation: 5
    },
    iconView: { flex: 0.1, paddingVertical: 40, marginLeft: 10 },





});

//make this component available to the app
export default RecycleBin;
