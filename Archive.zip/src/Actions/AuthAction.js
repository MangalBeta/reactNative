
// Login function 
export const loginrequest = () => {
    return "hello test"
}