

const initialState = {
    user: null
  }

// Auth Reducer
export default  (state = initialState, action)  => {
    switch (action.type) {

      default:
        return state
    }
  }

