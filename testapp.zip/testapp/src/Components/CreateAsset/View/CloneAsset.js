import React, { Component } from 'react';
import {
    View, Text, TextInput, Image, Dimensions, ScrollView, StyleSheet,
    KeyboardAvoidingView, Picker,TouchableOpacity

} from 'react-native';
const { width, height } = Dimensions.get('window')
import { StackNavigator, DrawerNavigator } from 'react-navigation';
import { Button } from 'react-native-elements';
import RNPickerSelect from 'react-native-picker-select';
import Icon from 'react-native-vector-icons/FontAwesome'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons'
import Entypo from 'react-native-vector-icons/Entypo'
// Import Images
import AppLogo from '../../../Assets/logo4x.png'
import MenuBar from '../../../Assets/menubar.png'
import ListTab from '../../../Assets/listtab2x.png'
import FindTab from '../../../Assets/findtab2x.png'
import CreateTab from '../../../Assets/createtab2x.png'
import AddIcon from '../../../Assets/plus-48.png'
import Search from '../../../Assets/noplanselectedicon.png'
import ArrowDown from '../../../Assets/arrow-48.png'

//Import component
import Header from '../../Common/Header'
import Dropdown from '../../Common/Dropdown'

// create a component
class CloneAsset extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: ``,
    });
    constructor() {
        super();
        this.state = {
            quantity: 0,
            condition: '',
            items: [
                {
                    label: 'Good',
                    value: 'Good',
                },
                {
                    label: 'Excellent',
                    value: 'Excellent',
                },
                {
                    label: 'Poor',
                    value: 'Poor',
                },
            ]
        }
    }
    increament() {
        this.setState({ quantity: (this.state.quantity + 1) })
    }
    decreament() {
        if (this.state.quantity != 0) {
            this.setState({ quantity: (this.state.quantity - 1) })
        }
    }
    openDrawer() {
        this.props.navigate('DrawerOpen')
    }
    renderSaveIcon() {
        return <Image source={MenuBar} style={{ width: 28, height: 28 }} resizeMode="contain" />

    }
    render() {
        let data = [{
            value: 'First Floor',
        }, {
            value: 'Second Floo',
        }, {
            value: 'First Floo',
        }];
        return (
            <View style={[styles.container, { flex: 1 }]}>
                <Header
                    leftIcon='arrow-left'
                    color={'black'}
                    sidebar={true}
                    goBack={this.props.navigation.goBack} 

                    navigateClick={() => this.props.navigation.navigate('Dashboard')} />
                {/* View*/}
                <View style={[{ flex: 1, padding: 20,backgroundColor:'white' }]}>
                    <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Current Active Location (PARENT)</Text>
                    <View style={{
                        flexDirection: 'row', borderColor: '#000', borderWidth: 2,
                        marginBottom: 10
                    }}>
                        <View style={{ flex: 6, paddingRight: 10,backgroundColor:'#CCCCCC' }}>
                            <TextInput placeholder="Serach"
                                underlineColorAndroid={"transparent"}
                                value={'B1 -04 Main Office Mohali'}
                                style={{ paddingLeft: 10, textAlignVertical: "center",
                                 height: 40 }} editable={true} />
                        </View>
                    
                    </View>
                    <View style={{ marginTop: 5 }}>
                        <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>New Location Name (CHILD)</Text>
                        <View style={{ flexDirection: 'row', marginBottom: 10 }}>
                            <View style={{ flex: 1, borderColor: '#000', borderWidth: 2, }}>
                                <TextInput placeholder="Serach"   value={'B1 -04 Main Office Mohali'}
                                    style={{ padding: 10, textAlignVertical: "top" }} editable={false} />
                            </View>
                       
                        </View>
                    </View>
                    <View style={{ marginTop: 5 }}>
                        <Text style={{ marginBottom: 5, fontSize: 16, color: '#000', }}>Description</Text>
                        <View style={{ borderColor: '#000', borderWidth: 2, }}>
                            <TextInput
                                placeholder="description"
                                underlineColorAndroid={"transparent"}
                                multiline={true}
                                value={'Reception area'}
                                numberOfLines={3}
                                style={{ padding: 5, height: 80, textAlignVertical: "top" }} editable={true} />
                        </View>
                    </View>
           
                    <View style={{ marginTop: 10,marginBottom:10 }}>
                        <Text style={{ fontSize: 16, color: '#000', }}>Location</Text>
                    </View>
                    <Dropdown data={this.state.items} label={'Select a Location'}/>
                    <View style={{ marginTop: 10 ,flex:1,justifyContent:'flex-end'}}>
                        <View style={{
                            justifyContent: 'center', borderColor: '#000',
                            borderWidth: 2, alignItems: 'center', backgroundColor: '#E69138',
                            marginBottom: 10
                        }}>
                            <TouchableOpacity onPress={() => this.props.navigation.navigate('')}>

                            <View style={{ flexDirection: 'row', padding: 10 }}>

                                <View style={{ marginRight: 5 }}>
                                    <Icon name="camera" size={28} color={"#000"} />
                                </View>
                                <View style={{ justifyContent: 'center' }}>
                                    <Text style={{ fontSize: 24, color: '#000' }}>ADD PHOTO</Text>
                                </View>

                            </View>
                            </TouchableOpacity>


                        </View>
                        <View style={{ justifyContent: 'center', borderColor: '#000',
                         borderWidth: 2, alignItems: 'center', backgroundColor: '#E69138' }}>
                                                    <TouchableOpacity onPress={() => this.props.navigation.navigate('List')}>

                            <View style={{ flexDirection: 'row', padding: 10 }}>

                                <View style={{ marginRight: 5 }}>
                                    <Icon name="database" size={28} color={"#000"} />
                                </View>
                                <View style={{ justifyContent: 'center' }}>
                                    <Text style={{ fontSize: 24, color: '#000' }}>DATABASE SAVE</Text>
                                </View>

                            </View>
                            </TouchableOpacity>

                        </View>
                    </View>

                </View>
            </View>
        );
    }
}

// define your styles
const styles = StyleSheet.create({
    label: { fontSize: 18, color: '#000', fontWeight: 'bold' },
    iconView: { flex: 1, paddingVertical: 40, marginLeft: 10 },
    inputView: {
        height: 45, marginTop: 10,
        // backgroundColor: '#DCD7D7',
        borderRadius: 5,
    },
    image: { width: width - 40, height: height / 4 },
    inputIOS: {
        fontSize: 16,
        height: 40,
        paddingTop: 10,
        paddingHorizontal: 10,
        paddingBottom: 10,
        borderWidth: 1,
        borderColor: 'gray',
        borderRadius: 4,
        backgroundColor: 'white',
    },


});

//make this component available to the app
export default CloneAsset;
